from odoo import http

class FormController(http.Controller):
    @http.route('/employee/form', auth='public', website = True)
    def index(self):
        return http.request.render('website_demo.employee_template')
  